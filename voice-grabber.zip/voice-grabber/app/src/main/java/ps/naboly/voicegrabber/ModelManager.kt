package ps.naboly.voicegrabber

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ModelManager {

    // الموديل العربي (فصحى) — يُحمّل مرة وحدة فقط
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-ar-mgb2-0.4.zip"
    private const val MODEL_DIR = "vosk-model-ar-mgb2-0.4"

    fun modelPath(ctx: Context): String =
        File(ctx.filesDir, MODEL_DIR).absolutePath

    fun isReady(ctx: Context): Boolean {
        val dir = File(ctx.filesDir, MODEL_DIR)
        return dir.exists() && File(dir, "conf").exists()
    }

    /**
     * يحمّل ويفك ضغط الموديل. progress: نسبة 0..100 (أو -1 إذا الحجم غير معروف).
     * يرمي Exception عند الفشل.
     */
    fun download(ctx: Context, progress: (Int) -> Unit) {
        if (isReady(ctx)) {
            progress(100)
            return
        }
        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30000
            readTimeout = 60000
            instanceFollowRedirects = true
        }
        conn.connect()
        val total = conn.contentLength.toLong()
        var read = 0L
        var lastPct = -1

        BufferedInputStream(conn.inputStream).use { raw ->
            // نلف الستريم بعدّاد بايتات ثم بـ ZipInputStream
            val counting = object : java.io.FilterInputStream(raw) {
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    val n = super.read(b, off, len)
                    if (n > 0) {
                        read += n
                        if (total > 0) {
                            val pct = ((read * 100) / total).toInt()
                            if (pct != lastPct) {
                                lastPct = pct
                                progress(pct)
                            }
                        } else {
                            progress(-1)
                        }
                    }
                    return n
                }
            }
            ZipInputStream(counting).use { zip ->
                var entry = zip.nextEntry
                val base = ctx.filesDir
                while (entry != null) {
                    val outFile = File(base, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { out ->
                            val buf = ByteArray(8192)
                            var c = zip.read(buf)
                            while (c != -1) {
                                out.write(buf, 0, c)
                                c = zip.read(buf)
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        conn.disconnect()
        progress(100)
    }
}
