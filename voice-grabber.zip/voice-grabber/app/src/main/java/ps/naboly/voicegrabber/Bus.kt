package ps.naboly.voicegrabber

import android.os.Handler
import android.os.Looper

object Bus {
    @Volatile
    var onText: ((text: String, isFinal: Boolean) -> Unit)? = null

    @Volatile
    var onStatus: ((message: String) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    fun text(t: String, isFinal: Boolean) {
        main.post { onText?.invoke(t, isFinal) }
    }

    fun status(m: String) {
        main.post { onStatus?.invoke(m) }
    }
}
