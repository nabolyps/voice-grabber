package ps.naboly.voicegrabber

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_PERMS = 101
    private val REQ_PROJECTION = 102

    private var selectedUid: Int = -1
    private var selectedLabel: String = ""
    private var finalText = StringBuilder()

    private lateinit var tvApp: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etText: EditText
    private lateinit var btnStartStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvApp = findViewById(R.id.tvApp)
        tvStatus = findViewById(R.id.tvStatus)
        etText = findViewById(R.id.etText)
        btnStartStop = findViewById(R.id.btnStartStop)

        findViewById<Button>(R.id.btnPickApp).setOnClickListener { showAppPicker() }
        btnStartStop.setOnClickListener { onStartStop() }
        findViewById<Button>(R.id.btnCopy).setOnClickListener { copyText() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveText() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            finalText = StringBuilder(); etText.setText("")
        }

        Bus.onText = { text, isFinal -> runOnUiThread { onText(text, isFinal) } }
        Bus.onStatus = { msg -> runOnUiThread { tvStatus.text = msg } }

        ensureModel()
    }

    // ---------- الموديل ----------
    private fun ensureModel() {
        if (ModelManager.isReady(this)) {
            tvStatus.text = "جاهز"
            return
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("تحميل الموديل العربي")
            .setMessage("أول مرة فقط — رح يحمّل ملف الموديل (~300 ميجا). تأكد إنك على واي فاي. تابع النسبة بالأسفل.")
            .setCancelable(false)
            .create()
        dlg.show()
        tvStatus.text = "تحميل الموديل…"
        Thread {
            try {
                ModelManager.download(this) { pct ->
                    runOnUiThread {
                        tvStatus.text = if (pct < 0) "تحميل الموديل…" else "تحميل الموديل… $pct%"
                    }
                }
                runOnUiThread { dlg.dismiss(); tvStatus.text = "جاهز ✅" }
            } catch (e: Exception) {
                runOnUiThread {
                    dlg.dismiss()
                    tvStatus.text = "فشل التحميل: ${e.message}"
                }
            }
        }.start()
    }

    // ---------- اختيار التطبيق ----------
    private fun showAppPicker() {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(main, 0)
        val apps = resolved
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val labels = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("اختر تطبيق")
            .setItems(labels) { _, i ->
                selectedUid = apps[i].uid
                selectedLabel = labels[i]
                tvApp.text = "التطبيق: $selectedLabel"
            }
            .show()
    }

    // ---------- تشغيل / إيقاف ----------
    private fun onStartStop() {
        if (AudioCaptureService.running) {
            stopService(Intent(this, AudioCaptureService::class.java))
            btnStartStop.text = "ابدأ"
            tvStatus.text = "متوقف"
            return
        }
        if (!ModelManager.isReady(this)) {
            Toast.makeText(this, "الموديل لسا عم بيحمّل", Toast.LENGTH_SHORT).show(); return
        }
        if (selectedUid < 0) {
            Toast.makeText(this, "اختر تطبيق أول", Toast.LENGTH_SHORT).show(); return
        }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)

        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), REQ_PERMS)
            return
        }
        requestProjection()
    }

    private fun requestProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                requestProjection()
            } else {
                Toast.makeText(this, "لازم تسمح بالميكروفون", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PROJECTION && resultCode == Activity.RESULT_OK && data != null) {
            val svc = Intent(this, AudioCaptureService::class.java).apply {
                putExtra("code", resultCode)
                putExtra("data", data)
                putExtra("uid", selectedUid)
                putExtra("model", ModelManager.modelPath(this@MainActivity))
            }
            startForegroundService(svc)
            btnStartStop.text = "إيقاف"
            tvStatus.text = "جاري التشغيل…"
        } else if (requestCode == REQ_PROJECTION) {
            Toast.makeText(this, "لازم توافق على التقاط الصوت", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- النص ----------
    private fun onText(text: String, isFinal: Boolean) {
        if (isFinal) {
            if (text.isNotEmpty()) {
                if (finalText.isNotEmpty()) finalText.append(" ")
                finalText.append(text)
                etText.setText(finalText.toString())
            }
        } else {
            val shown = if (finalText.isEmpty()) text else "$finalText $text"
            etText.setText(shown)
        }
        etText.setSelection(etText.text.length)
    }

    private fun copyText() {
        val t = etText.text.toString()
        if (t.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("نص", t))
        Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
    }

    private fun saveText() {
        val t = etText.text.toString()
        if (t.isEmpty()) return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "النص_${System.currentTimeMillis()}.txt")
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { it.write(t.toByteArray()) }
                Toast.makeText(this, "تم الحفظ في Downloads", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Bus.onText = null
        Bus.onStatus = null
        super.onDestroy()
    }
}
