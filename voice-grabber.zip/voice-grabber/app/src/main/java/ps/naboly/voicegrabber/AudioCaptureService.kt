package ps.naboly.voicegrabber

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

class AudioCaptureService : Service() {

    companion object {
        @Volatile
        var running: Boolean = false
        const val ACTION_STOP = "STOP"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 1
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotif()

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        val uid = intent?.getIntExtra("uid", -1) ?: -1
        val modelPath = intent?.getStringExtra("model") ?: ""

        if (data == null || uid < 0 || modelPath.isEmpty()) {
            Bus.status("بيانات ناقصة — أعد المحاولة")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startCapture(code, data, uid, modelPath)
        } catch (e: Exception) {
            Bus.status("خطأ بالتشغيل: ${e.message}")
            stopEverything()
            stopSelf()
        }
        return START_STICKY
    }

    private fun startCapture(code: Int, data: Intent, uid: Int, modelPath: String) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopEverything()
                stopSelf()
            }
        }, null)

        val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUid(uid)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBuf = AudioRecord.getMinBufferSize(
            16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = if (minBuf > 0) minBuf * 2 else 8192

        record = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufSize)
            .setAudioPlaybackCaptureConfig(config)
            .build()

        Bus.status("تحميل الموديل…")
        model = Model(modelPath)
        recognizer = Recognizer(model, 16000.0f)

        record?.startRecording()
        running = true
        Bus.status("عم بيسجّل ✅")

        worker = Thread {
            val buffer = ByteArray(4096)
            while (running) {
                val n = record?.read(buffer, 0, buffer.size) ?: -1
                if (n > 0) {
                    val rec = recognizer ?: break
                    if (rec.acceptWaveForm(buffer, n)) {
                        val text = JSONObject(rec.result).optString("text").trim()
                        if (text.isNotEmpty()) Bus.text(text, true)
                    } else {
                        val partial = JSONObject(rec.partialResult).optString("partial").trim()
                        Bus.text(partial, false)
                    }
                }
            }
        }
        worker?.start()
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "التسجيل", NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(ch)
        }
        val notif: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("تفريغ الصوت شغّال")
            .setContentText("عم يلتقط صوت التطبيق المختار")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun stopEverything() {
        running = false
        try { worker?.join(500) } catch (_: Exception) {}
        worker = null
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
        try { recognizer?.close() } catch (_: Exception) {}
        recognizer = null
        try { model?.close() } catch (_: Exception) {}
        model = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }
}
